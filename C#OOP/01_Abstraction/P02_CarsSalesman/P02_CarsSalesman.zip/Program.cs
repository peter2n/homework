﻿

namespace P02_CarsSalesman
{
    class CarSalesman
    {
        static void Main(string[] args)
        {
            Runner.Run();
        }
    }

}
